Put your audio files here (mp3).
Keep these exact names, or edit the list in index.html (search for EDIT THIS LIST):

midnight-drive.mp3
golden-hour.mp3
sangeet-night-mix.mp3

Tip: use 1 to 2 minute sample clips (about 2 MB each). GitHub web upload allows files up to 25 MB.
