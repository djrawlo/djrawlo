Put your video files here (mp4).
Keep these exact names, or edit the list in index.html (search for EDIT THIS LIST):

club-night.mp4
wedding-highlights.mp4
corporate-night.mp4

Tip: keep clips short and under 25 MB for GitHub web upload. For long videos, upload to YouTube and put the video ID in index.html instead.
