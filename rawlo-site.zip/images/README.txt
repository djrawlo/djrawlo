To replace a picture, upload a new file with the same name:

logo.png (transparent logo)
hero-banner.jpg (big photo under the logo)
gallery-led-booth.jpg
gallery-beach-set.jpg
gallery-wedding.jpg
gallery-rooftop.jpg
gallery-citadel-flyer.jpg
